<?php

class AdminController extends ModuleAdminController
{
       
    // you can use symfony DI to inject services
    public function __construct()
    {
        parent::__construct();

    }

    public function init(){
        parent::init();
    }
    
    public function initContent(){
        parent::initContent();
        $this->context->smarty->assign(array());
        $this.setTemplate('adminController.tpl');
    }
}
?>